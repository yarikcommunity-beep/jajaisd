import { z } from 'zod';
import { insertUserSchema, items, cases, users } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  auth: {
    login: {
      method: 'POST' as const,
      path: '/api/auth/login',
      input: z.object({ walletAddress: z.string() }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        201: z.custom<typeof users.$inferSelect>(), // Created
      },
    },
    me: {
      method: 'GET' as const,
      path: '/api/auth/me',
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
  },
  cases: {
    list: {
      method: 'GET' as const,
      path: '/api/cases',
      responses: {
        200: z.array(z.custom<typeof cases.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/cases/:id',
      responses: {
        200: z.custom<typeof cases.$inferSelect & { drops: any[] }>(),
        404: errorSchemas.notFound,
      },
    },
    open: {
      method: 'POST' as const,
      path: '/api/cases/:id/open',
      responses: {
        200: z.object({ item: z.custom<typeof items.$inferSelect>() }),
        400: z.object({ message: z.string() }), // Insufficient balance
        404: errorSchemas.notFound,
      },
    },
  },
  daily: {
    spin: {
      method: 'POST' as const,
      path: '/api/daily/spin',
      responses: {
        200: z.object({ 
          item: z.custom<typeof items.$inferSelect>(),
          message: z.string()
        }),
        400: z.object({ message: z.string(), cooldown: z.boolean() }),
      },
    },
  },
  user: {
    items: {
      method: 'GET' as const,
      path: '/api/user/items',
      responses: {
        200: z.array(z.custom<typeof items.$inferSelect>()),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
