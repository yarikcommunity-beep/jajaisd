import { pgTable, text, serial, integer, boolean, timestamp, numeric } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").unique(),
  balance: numeric("balance").default("0"), // In TON
  lastDailySpin: timestamp("last_daily_spin"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const items = pgTable("items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'nft', 'token', 'gift'
  value: numeric("value").notNull(), // Estimated value in TON
  imageUrl: text("image_url").notNull(),
  isSnoopDogg: boolean("is_snoop_dogg").default(false), // Special flag for Daily Spin
});

export const cases = pgTable("cases", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  price: numeric("price").notNull(),
  imageUrl: text("image_url").notNull(),
  description: text("description"),
});

export const caseDrops = pgTable("case_drops", {
  id: serial("id").primaryKey(),
  caseId: integer("case_id").references(() => cases.id).notNull(),
  itemId: integer("item_id").references(() => items.id).notNull(),
  probability: numeric("probability").notNull(), // 0-1
});

export const userItems = pgTable("user_items", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  itemId: integer("item_id").references(() => items.id).notNull(),
  acquiredAt: timestamp("acquired_at").defaultNow(),
});

// === RELATIONS ===
export const casesRelations = relations(cases, ({ many }) => ({
  drops: many(caseDrops),
}));

export const caseDropsRelations = relations(caseDrops, ({ one }) => ({
  case: one(cases, {
    fields: [caseDrops.caseId],
    references: [cases.id],
  }),
  item: one(items, {
    fields: [caseDrops.itemId],
    references: [items.id],
  }),
}));

export const userItemsRelations = relations(userItems, ({ one }) => ({
  user: one(users, {
    fields: [userItems.userId],
    references: [users.id],
  }),
  item: one(items, {
    fields: [userItems.itemId],
    references: [items.id],
  }),
}));

// === EXPLICIT API CONTRACT TYPES ===
export type User = typeof users.$inferSelect;
export type Item = typeof items.$inferSelect;
export type Case = typeof cases.$inferSelect;
export type CaseDrop = typeof caseDrops.$inferSelect;

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });

// Responses
export type LoginRequest = { walletAddress: string };
export type DailySpinResponse = { item: Item; cooldown: boolean; message: string };
export type OpenCaseResponse = { item: Item };

