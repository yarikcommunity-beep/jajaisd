import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useUserItems() {
  return useQuery({
    queryKey: [api.user.items.path],
    queryFn: async () => {
      const res = await fetch(api.user.items.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch items");
      return api.user.items.responses[200].parse(await res.json());
    },
  });
}
