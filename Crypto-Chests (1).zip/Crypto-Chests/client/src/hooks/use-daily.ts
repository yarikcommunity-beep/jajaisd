import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useDailySpin() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.daily.spin.path, {
        method: api.daily.spin.method,
        credentials: "include",
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message);
      }
      return api.daily.spin.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.auth.me.path] });
      queryClient.invalidateQueries({ queryKey: [api.user.items.path] });
      toast({
        title: "Daily Spin Result",
        description: data.message,
      });
    },
    onError: (error) => {
      toast({
        title: "Spin Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
