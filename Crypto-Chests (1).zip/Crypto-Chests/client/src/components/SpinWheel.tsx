import { useState, useRef } from "react";
import { motion, useAnimation } from "framer-motion";
import { type Item } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { useDailySpin } from "@/hooks/use-daily";

export function SpinWheel() {
  const [isSpinning, setIsSpinning] = useState(false);
  const controls = useAnimation();
  const { mutate: spin, isPending } = useDailySpin();
  const [result, setResult] = useState<Item | null>(null);

  const handleSpin = () => {
    if (isSpinning || isPending) return;
    setIsSpinning(true);
    setResult(null);

    spin(undefined, {
      onSuccess: async (data) => {
        // Mock spin animation
        // In a real app, calculate rotation based on item index
        const randomRotations = 1440 + Math.random() * 360; 
        
        await controls.start({
          rotate: randomRotations,
          transition: { duration: 4, ease: "circOut" }
        });

        setResult(data.item);
        setIsSpinning(false);
      },
      onError: () => {
        setIsSpinning(false);
      }
    });
  };

  // Mock items for visual
  const segments = Array(8).fill(null);

  return (
    <div className="flex flex-col items-center justify-center gap-8">
      <div className="relative w-64 h-64 sm:w-80 sm:h-80">
        {/* Pointer */}
        <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-20 w-8 h-10 bg-white clip-path-polygon-[50%_100%,_0_0,_100%_0] drop-shadow-[0_0_10px_rgba(255,255,255,0.8)]" />

        {/* Wheel */}
        <motion.div
          animate={controls}
          className="w-full h-full rounded-full border-4 border-white/20 bg-black relative overflow-hidden shadow-[0_0_50px_rgba(255,255,255,0.1)]"
        >
          {segments.map((_, i) => (
            <div
              key={i}
              className="absolute w-full h-full border-r border-white/10 origin-center"
              style={{
                transform: `rotate(${i * (360 / segments.length)}deg)`,
                clipPath: "polygon(50% 50%, 50% 0, 100% 0, 100% 50%)" // Not quite right for segments but visual enough for cyber effect
              }}
            >
              <div 
                className="absolute top-4 right-1/4 transform rotate-45 text-xs font-mono text-gray-400"
              >
                {i % 2 === 0 ? "TON" : "NFT"}
              </div>
            </div>
          ))}
          
          {/* Center Hub */}
          <div className="absolute inset-0 m-auto w-16 h-16 bg-gradient-to-br from-gray-800 to-black rounded-full border-2 border-white/30 z-10 flex items-center justify-center">
             <span className="font-display font-bold text-white text-xs">DAILY</span>
          </div>
        </motion.div>
      </div>

      <div className="text-center space-y-4">
        {result ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-6 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-sm"
          >
            <h3 className="text-lg font-bold text-white mb-2">YOU WON!</h3>
            <div className="flex items-center gap-4">
              <img src={result.imageUrl} alt={result.name} className="w-16 h-16 object-contain" />
              <div className="text-left">
                <p className="font-display text-xl text-white text-glow">{result.name}</p>
                <p className="text-xs text-gray-400 font-mono">{result.value} TON VALUE</p>
              </div>
            </div>
          </motion.div>
        ) : (
          <div className="h-24 flex items-center justify-center">
            <p className="text-gray-500 font-mono text-sm uppercase tracking-widest">
              Spin to win rare prizes
            </p>
          </div>
        )}

        <Button
          onClick={handleSpin}
          disabled={isSpinning || isPending}
          className="w-full max-w-xs h-14 text-lg font-bold tracking-widest uppercase bg-white text-black hover:bg-gray-200 shadow-[0_0_30px_rgba(255,255,255,0.2)] hover:shadow-[0_0_50px_rgba(255,255,255,0.4)] transition-all duration-300 rounded-xl"
        >
          {isSpinning ? "SPINNING..." : "SPIN NOW"}
        </Button>
      </div>
    </div>
  );
}
