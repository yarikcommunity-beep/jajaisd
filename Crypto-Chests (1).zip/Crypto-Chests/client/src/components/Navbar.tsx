import { Link, useLocation } from "wouter";
import { Wallet, Package, Gift, Home } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function Navbar() {
  const [location] = useLocation();
  const { user, login, isLoggingIn } = useAuth();

  const handleConnect = () => {
    // Mock connection
    login({ walletAddress: "EQD...MOCK" });
  };

  const navItems = [
    { href: "/", icon: Home, label: "Home" },
    { href: "/cases", icon: Package, label: "Cases" },
    { href: "/daily", icon: Gift, label: "Daily" },
    { href: "/inventory", icon: Wallet, label: "Inventory" },
  ];

  return (
    <nav className="fixed top-0 w-full z-50 border-b border-white/10 bg-black/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-black font-bold text-lg">
              T
            </div>
            <span className="text-xl font-display font-bold tracking-wider hidden sm:block">
              TON CASES
            </span>
          </Link>

          <div className="flex items-center gap-2 sm:gap-6">
            <div className="flex items-center gap-1 sm:gap-4 bg-white/5 rounded-full px-4 py-1.5 border border-white/10">
              {navItems.map((item) => {
                const isActive = location === item.href;
                const Icon = item.icon;
                return (
                  <Link 
                    key={item.href} 
                    href={item.href}
                    className={cn(
                      "p-2 rounded-full transition-all duration-300 hover:bg-white/10 hover:text-white",
                      isActive ? "bg-white text-black hover:bg-white hover:text-black shadow-[0_0_15px_rgba(255,255,255,0.5)]" : "text-gray-400"
                    )}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="sr-only">{item.label}</span>
                  </Link>
                );
              })}
            </div>

            {user ? (
              <div className="flex items-center gap-3">
                <div className="hidden md:flex flex-col items-end">
                  <span className="text-xs text-gray-400 font-mono">BALANCE</span>
                  <span className="text-sm font-bold font-mono text-white text-glow">
                    {user.balance} TON
                  </span>
                </div>
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gray-800 to-black border border-white/20 flex items-center justify-center">
                  <Wallet className="w-5 h-5 text-white" />
                </div>
              </div>
            ) : (
              <Button 
                onClick={handleConnect}
                disabled={isLoggingIn}
                className="bg-white text-black hover:bg-gray-200 font-bold tracking-wide rounded-full px-6 shadow-[0_0_20px_rgba(255,255,255,0.3)] hover:shadow-[0_0_30px_rgba(255,255,255,0.5)] transition-all duration-300 transform hover:scale-105"
              >
                {isLoggingIn ? "CONNECTING..." : "CONNECT WALLET"}
              </Button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
