import { Link } from "wouter";
import { motion } from "framer-motion";
import { type Case } from "@shared/schema";

interface CaseCardProps {
  caseData: Case;
}

export function CaseCard({ caseData }: CaseCardProps) {
  return (
    <Link href={`/cases/${caseData.id}`}>
      <motion.div
        whileHover={{ y: -5, scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className="group relative cursor-pointer"
      >
        <div className="absolute -inset-0.5 bg-gradient-to-b from-white to-transparent opacity-20 group-hover:opacity-50 blur transition duration-500 rounded-3xl" />
        <div className="relative h-full bg-black border border-white/10 rounded-3xl p-6 flex flex-col items-center justify-between overflow-hidden">
          
          {/* Background Gradient */}
          <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

          {/* Price Tag */}
          <div className="absolute top-4 right-4 bg-white/10 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
            <span className="text-sm font-mono font-bold text-white group-hover:text-glow">
              {caseData.price} TON
            </span>
          </div>

          {/* Image Container */}
          <div className="w-full aspect-square flex items-center justify-center mb-4 relative z-10">
            <motion.img 
              src={caseData.imageUrl} 
              alt={caseData.name}
              className="w-3/4 h-3/4 object-contain drop-shadow-[0_0_15px_rgba(255,255,255,0.2)] group-hover:drop-shadow-[0_0_25px_rgba(255,255,255,0.4)] transition-all duration-500"
              initial={{ rotate: 0 }}
              whileHover={{ rotate: [0, -5, 5, 0], transition: { duration: 0.5 } }}
            />
          </div>

          {/* Info */}
          <div className="text-center relative z-10 w-full">
            <h3 className="text-xl font-bold text-white mb-1 tracking-wide group-hover:text-glow transition-all">
              {caseData.name}
            </h3>
            <p className="text-xs text-gray-500 uppercase tracking-widest group-hover:text-gray-300 transition-colors">
              {caseData.description || "Contains rare items"}
            </p>
          </div>

          {/* Hover Button Effect */}
          <div className="w-full mt-4 h-0 group-hover:h-10 opacity-0 group-hover:opacity-100 transition-all duration-300 overflow-hidden">
            <div className="w-full h-10 bg-white text-black font-bold flex items-center justify-center rounded-xl text-sm uppercase tracking-wider">
              Open Case
            </div>
          </div>
        </div>
      </motion.div>
    </Link>
  );
}
