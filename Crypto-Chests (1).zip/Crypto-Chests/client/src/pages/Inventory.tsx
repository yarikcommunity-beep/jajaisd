import { Navbar } from "@/components/Navbar";
import { StarBackground } from "@/components/StarBackground";
import { useUserItems } from "@/hooks/use-user-items";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, Search } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export default function Inventory() {
  const { user } = useAuth();
  const { data: items, isLoading } = useUserItems();

  if (!user) {
    return (
      <div className="min-h-screen relative flex flex-col">
        <StarBackground />
        <Navbar />
        <main className="flex-1 flex flex-col items-center justify-center text-center p-4">
          <h2 className="text-3xl font-display font-bold text-white mb-4">CONNECT WALLET</h2>
          <p className="text-gray-400 mb-8">Please connect your TON wallet to view your inventory.</p>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative flex flex-col">
      <StarBackground />
      <Navbar />

      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12 w-full">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
          <div>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-2">INVENTORY</h1>
            <p className="text-gray-400 font-mono">TOTAL VALUE: {items?.reduce((acc, i) => acc + Number(i.value), 0) || 0} TON</p>
          </div>
          
          <div className="relative w-full md:w-64">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
             <input 
                type="text" 
                placeholder="Search items..." 
                className="w-full bg-white/5 border border-white/10 rounded-full py-2 pl-10 pr-4 text-sm text-white focus:outline-none focus:border-white/30 transition-colors"
             />
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-10 h-10 text-white animate-spin" />
          </div>
        ) : !items || items.length === 0 ? (
          <div className="text-center py-32 border border-dashed border-white/10 rounded-3xl bg-white/5">
            <p className="text-gray-500 font-mono mb-6">NO ITEMS FOUND</p>
            <Button className="rounded-full bg-white text-black hover:bg-gray-200">
              Open Your First Case
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
            {items.map((item, index) => (
              <motion.div
                key={item.id} // Note: This uses item definition ID, in real app need unique instance ID
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className="bg-black border border-white/10 rounded-2xl p-4 group hover:border-white/30 transition-colors relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                
                <div className="aspect-square flex items-center justify-center mb-4 bg-white/5 rounded-xl">
                  <img src={item.imageUrl} alt={item.name} className="w-2/3 h-2/3 object-contain drop-shadow-[0_0_10px_rgba(255,255,255,0.3)]" />
                </div>
                
                <div className="space-y-1 relative z-10">
                  <h3 className="font-bold text-white text-sm truncate">{item.name}</h3>
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] text-gray-400 uppercase bg-white/10 px-2 py-0.5 rounded text-xs">{item.type}</span>
                    <span className="text-xs font-mono text-white">{item.value} TON</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
