import { motion } from "framer-motion";
import { Navbar } from "@/components/Navbar";
import { StarBackground } from "@/components/StarBackground";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Trophy, Zap, Shield } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen relative flex flex-col">
      <StarBackground />
      <Navbar />

      <main className="flex-1 flex flex-col items-center justify-center px-4 pt-20 pb-12">
        {/* Hero Section */}
        <div className="max-w-4xl mx-auto text-center space-y-8 mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl lg:text-9xl font-display font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-500 tracking-tighter mb-4 filter drop-shadow-[0_0_20px_rgba(255,255,255,0.3)]">
              TON CASES
            </h1>
            <p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto font-light tracking-wide">
              The premium mystery box experience on TON. Win NFTs, Tokens, and exclusive digital assets.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Link href="/cases">
              <Button className="h-14 px-8 rounded-full bg-white text-black hover:bg-gray-200 text-lg font-bold tracking-wider shadow-[0_0_30px_rgba(255,255,255,0.3)] transition-all hover:scale-105">
                OPEN CASES
              </Button>
            </Link>
            <Link href="/daily">
              <Button variant="outline" className="h-14 px-8 rounded-full border-white/20 text-white hover:bg-white/10 text-lg font-bold tracking-wider backdrop-blur-sm transition-all hover:scale-105">
                DAILY SPIN
              </Button>
            </Link>
          </motion.div>
        </div>

        {/* Stats / Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto w-full">
          {[
            { icon: Trophy, title: "Rare Drops", desc: "Exclusive NFTs & Tokens" },
            { icon: Zap, title: "Instant", desc: "Withdraw to wallet instantly" },
            { icon: Shield, title: "Provably Fair", desc: "Transparent drop rates" },
          ].map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + i * 0.1 }}
              className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-sm hover:bg-white/10 transition-colors group"
            >
              <feature.icon className="w-8 h-8 text-white mb-4 group-hover:drop-shadow-[0_0_10px_rgba(255,255,255,0.8)] transition-all" />
              <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
              <p className="text-gray-400 text-sm">{feature.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* Live Drops Ticker (Mock) */}
        <div className="w-full max-w-6xl mt-24 border-t border-white/10 pt-8">
          <div className="flex items-center gap-2 mb-4">
             <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
             <span className="text-xs font-mono uppercase text-gray-400 tracking-widest">Live Drops</span>
          </div>
          <div className="flex gap-4 overflow-hidden mask-linear-fade">
             {[1,2,3,4,5,6].map((i) => (
                <div key={i} className="flex-shrink-0 w-48 bg-black border border-white/10 rounded-xl p-3 flex items-center gap-3">
                   <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                      <span className="text-lg">💎</span>
                   </div>
                   <div>
                      <p className="text-xs font-bold text-white">Rare Gem #{1000+i}</p>
                      <p className="text-[10px] text-gray-500">User...{i*82}</p>
                   </div>
                </div>
             ))}
          </div>
        </div>
      </main>
    </div>
  );
}
