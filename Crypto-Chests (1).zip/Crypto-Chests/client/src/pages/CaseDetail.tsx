import { useState } from "react";
import { useRoute } from "wouter";
import { Navbar } from "@/components/Navbar";
import { StarBackground } from "@/components/StarBackground";
import { useCase, useOpenCase } from "@/hooks/use-cases";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { Item } from "@shared/schema";
import { ArrowLeft, Loader2 } from "lucide-react";
import { Link } from "wouter";

export default function CaseDetail() {
  const [, params] = useRoute("/cases/:id");
  const id = parseInt(params?.id || "0");
  const { data: caseData, isLoading } = useCase(id);
  const { mutate: openCase, isPending } = useOpenCase();
  
  const [openedItem, setOpenedItem] = useState<Item | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);

  const handleOpen = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setOpenedItem(null);

    openCase(id, {
      onSuccess: (data) => {
        // Mock delay for animation
        setTimeout(() => {
          setOpenedItem(data.item);
          setIsAnimating(false);
        }, 3000);
      },
      onError: () => {
        setIsAnimating(false);
      }
    });
  };

  if (isLoading || !caseData) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-white animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen relative flex flex-col overflow-hidden">
      <StarBackground />
      <Navbar />

      <main className="flex-1 flex flex-col items-center justify-center px-4 pt-20 pb-12 relative z-10">
        <div className="absolute top-24 left-4 sm:left-8">
          <Link href="/cases" className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span className="uppercase font-bold text-sm tracking-wider">Back</span>
          </Link>
        </div>

        <div className="max-w-4xl w-full mx-auto flex flex-col items-center">
          <AnimatePresence mode="wait">
            {openedItem ? (
              <motion.div
                key="result"
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="text-center space-y-8"
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-white/20 blur-[100px] rounded-full" />
                  <img 
                    src={openedItem.imageUrl} 
                    alt={openedItem.name} 
                    className="w-64 h-64 object-contain relative z-10 drop-shadow-[0_0_30px_rgba(255,255,255,0.5)]" 
                  />
                </div>
                <div>
                  <h2 className="text-4xl font-display font-bold text-white text-glow mb-2">{openedItem.name}</h2>
                  <p className="text-xl text-gray-400 font-mono">{openedItem.value} TON VALUE</p>
                </div>
                <div className="flex gap-4 justify-center">
                  <Button 
                    onClick={() => setOpenedItem(null)}
                    className="h-12 px-8 rounded-full bg-white text-black font-bold uppercase tracking-wider hover:scale-105 transition-all"
                  >
                    Open Another
                  </Button>
                  <Link href="/inventory">
                    <Button variant="outline" className="h-12 px-8 rounded-full border-white/20 text-white font-bold uppercase tracking-wider hover:bg-white/10">
                      View Inventory
                    </Button>
                  </Link>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="case"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0, scale: 1.5, filter: "blur(20px)" }}
                className="text-center space-y-12"
              >
                <div className="relative">
                  {/* Case Shake Animation */}
                  <motion.div
                    animate={isAnimating ? {
                      x: [-5, 5, -5, 5, 0],
                      scale: [1, 1.05, 1],
                      filter: ["brightness(1)", "brightness(1.5)", "brightness(1)"]
                    } : {}}
                    transition={{ 
                      duration: 0.5, 
                      repeat: isAnimating ? Infinity : 0,
                      ease: "easeInOut"
                    }}
                  >
                     {/* Glow behind case */}
                     <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-white/5 rounded-full blur-[60px]" />
                     
                    <img 
                      src={caseData.imageUrl} 
                      alt={caseData.name} 
                      className="w-80 h-80 object-contain relative z-10 drop-shadow-[0_0_20px_rgba(255,255,255,0.1)]"
                    />
                  </motion.div>
                </div>

                <div className="space-y-6">
                  <div>
                    <h1 className="text-5xl font-display font-bold text-white mb-2">{caseData.name}</h1>
                    <p className="text-xl text-gray-400 font-mono tracking-widest">{caseData.price} TON</p>
                  </div>

                  <Button
                    onClick={handleOpen}
                    disabled={isAnimating || isPending}
                    className="h-16 px-12 text-xl rounded-2xl bg-white text-black hover:bg-gray-200 font-bold tracking-[0.2em] shadow-[0_0_40px_rgba(255,255,255,0.2)] hover:shadow-[0_0_60px_rgba(255,255,255,0.4)] transition-all transform hover:scale-105"
                  >
                    {isAnimating || isPending ? (
                      <span className="flex items-center gap-3">
                        OPENING <Loader2 className="w-5 h-5 animate-spin" />
                      </span>
                    ) : "OPEN CASE"}
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Possible Drops */}
          {!openedItem && !isAnimating && (
            <div className="mt-24 w-full">
              <h3 className="text-sm font-mono uppercase text-gray-500 mb-6 tracking-widest text-center">Possible Drops</h3>
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4">
                {/* Visual mock of drops, would normally come from caseData.drops */}
                {[1,2,3,4,5,6].map((i) => (
                  <div key={i} className="bg-white/5 border border-white/10 rounded-xl p-4 flex flex-col items-center gap-2 group hover:bg-white/10 transition-colors cursor-pointer">
                    <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center">
                      <span className="text-xl group-hover:scale-125 transition-transform">🎁</span>
                    </div>
                    <span className="text-[10px] font-bold text-gray-400 uppercase">Item {i}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
