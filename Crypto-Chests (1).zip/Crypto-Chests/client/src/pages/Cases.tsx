import { Navbar } from "@/components/Navbar";
import { StarBackground } from "@/components/StarBackground";
import { CaseCard } from "@/components/CaseCard";
import { useCases } from "@/hooks/use-cases";
import { motion } from "framer-motion";

export default function Cases() {
  const { data: cases, isLoading } = useCases();

  return (
    <div className="min-h-screen relative flex flex-col">
      <StarBackground />
      <Navbar />

      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12 w-full">
        <div className="mb-12 text-center md:text-left">
          <h1 className="text-4xl md:text-6xl font-display font-bold text-white mb-4 text-glow">
            AVAILABLE CASES
          </h1>
          <p className="text-gray-400 max-w-2xl text-lg font-light">
            Unlock premium rewards. Higher tiers contain exclusive Snoop Dogg NFTs and large TON bounties.
          </p>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="aspect-[3/4] rounded-3xl bg-white/5 animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {cases?.map((caseItem, index) => (
              <motion.div
                key={caseItem.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <CaseCard caseData={caseItem} />
              </motion.div>
            ))}
            {(!cases || cases.length === 0) && (
              <div className="col-span-full text-center py-20 text-gray-500 font-mono">
                NO CASES AVAILABLE YET
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
