import { Navbar } from "@/components/Navbar";
import { StarBackground } from "@/components/StarBackground";
import { SpinWheel } from "@/components/SpinWheel";

export default function Daily() {
  return (
    <div className="min-h-screen relative flex flex-col">
      <StarBackground />
      <Navbar />

      <main className="flex-1 flex flex-col items-center justify-center px-4 pt-20 pb-12">
        <div className="max-w-2xl w-full text-center space-y-12">
          <div className="space-y-4">
            <h1 className="text-4xl md:text-6xl font-display font-bold text-white text-glow">
              DAILY REWARDS
            </h1>
            <p className="text-gray-400 max-w-lg mx-auto">
              Spin the wheel every 24 hours for a chance to win free TON, exclusive NFTs, or the rare Snoop Dogg collectible.
            </p>
          </div>

          <SpinWheel />

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-12 text-left">
            {[
              { label: "Rare NFT", chance: "1%" },
              { label: "0.3 TON", chance: "5%" },
              { label: "0.2 TON", chance: "15%" },
              { label: "0.1 TON", chance: "30%" },
            ].map((item, i) => (
              <div key={i} className="bg-white/5 border border-white/10 rounded-xl p-4">
                <p className="text-white font-bold">{item.label}</p>
                <p className="text-xs text-gray-500 font-mono mt-1">CHANCE: {item.chance}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
