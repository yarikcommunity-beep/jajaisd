## Packages
framer-motion | Essential for complex animations (twinkling stars, wheel spin, case opening)
lucide-react | Icon library (already in stack, but noting for usage)
clsx | For conditional class names
tailwind-merge | For merging tailwind classes safely

## Notes
- Images: Copy attached_assets/image_1767361072427.png to client/public/images/frog_case.png
- Theme: Black and white monochrome with high contrast and subtle glow effects
- Animations: Starfield background, spinning wheel, case shake/reveal
- Wallet: Mock connection logic for now, using localStorage to simulate auth state
