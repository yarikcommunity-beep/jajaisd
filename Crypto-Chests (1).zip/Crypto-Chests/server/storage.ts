import { db } from "./db";
import {
  users, items, cases, caseDrops, userItems,
  type User, type Item, type Case, type CaseDrop
} from "@shared/schema";
import { eq, sql } from "drizzle-orm";

export interface IStorage {
  // User
  getUser(id: number): Promise<User | undefined>;
  getUserByWallet(address: string): Promise<User | undefined>;
  createUser(walletAddress: string): Promise<User>;
  updateUserBalance(id: number, amount: string): Promise<User>;
  updateUserLastDailySpin(id: number): Promise<User>;

  // Cases & Items
  getCases(): Promise<Case[]>;
  getCase(id: number): Promise<(Case & { drops: (CaseDrop & { item: Item })[] }) | undefined>;
  getItems(): Promise<Item[]>;
  getItem(id: number): Promise<Item | undefined>;
  
  // Creation (for seeding)
  createItem(item: typeof items.$inferInsert): Promise<Item>;
  createCase(caseData: typeof cases.$inferInsert): Promise<Case>;
  addCaseDrop(drop: typeof caseDrops.$inferInsert): Promise<CaseDrop>;
  
  // Gameplay
  addItemToUser(userId: number, itemId: number): Promise<void>;
  getUserItems(userId: number): Promise<Item[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByWallet(address: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.walletAddress, address));
    return user;
  }

  async createUser(walletAddress: string): Promise<User> {
    const [user] = await db.insert(users).values({ walletAddress }).returning();
    return user;
  }

  async updateUserBalance(id: number, amount: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ balance: amount })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserLastDailySpin(id: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ lastDailySpin: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getCases(): Promise<Case[]> {
    return await db.select().from(cases);
  }

  async getCase(id: number): Promise<(Case & { drops: (CaseDrop & { item: Item })[] }) | undefined> {
    const [caseData] = await db.select().from(cases).where(eq(cases.id, id));
    if (!caseData) return undefined;

    const dropsData = await db
      .select({
        drop: caseDrops,
        item: items,
      })
      .from(caseDrops)
      .innerJoin(items, eq(caseDrops.itemId, items.id))
      .where(eq(caseDrops.caseId, id));

    return {
      ...caseData,
      drops: dropsData.map((d) => ({ ...d.drop, item: d.item })),
    };
  }

  async getItems(): Promise<Item[]> {
    return await db.select().from(items);
  }

  async getItem(id: number): Promise<Item | undefined> {
    const [item] = await db.select().from(items).where(eq(items.id, id));
    return item;
  }

  async createItem(item: typeof items.$inferInsert): Promise<Item> {
    const [newItem] = await db.insert(items).values(item).returning();
    return newItem;
  }

  async createCase(caseData: typeof cases.$inferInsert): Promise<Case> {
    const [newCase] = await db.insert(cases).values(caseData).returning();
    return newCase;
  }

  async addCaseDrop(drop: typeof caseDrops.$inferInsert): Promise<CaseDrop> {
    const [newDrop] = await db.insert(caseDrops).values(drop).returning();
    return newDrop;
  }

  async addItemToUser(userId: number, itemId: number): Promise<void> {
    await db.insert(userItems).values({ userId, itemId });
  }

  async getUserItems(userId: number): Promise<Item[]> {
    const result = await db
      .select({ item: items })
      .from(userItems)
      .innerJoin(items, eq(userItems.itemId, items.id))
      .where(eq(userItems.userId, userId));
    return result.map((r) => r.item);
  }
}

export const storage = new DatabaseStorage();
