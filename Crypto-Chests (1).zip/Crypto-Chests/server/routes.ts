import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api, errorSchemas } from "@shared/routes";
import { z } from "zod";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Session Middleware
  app.use(session({
    secret: process.env.SESSION_SECRET || "default_secret",
    resave: false,
    saveUninitialized: false,
    cookie: { 
      secure: app.get("env") === "production",
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    },
    store: new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    }),
  }));

  // Auth
  app.post(api.auth.login.path, async (req, res) => {
    try {
      const { walletAddress } = api.auth.login.input.parse(req.body);
      let user = await storage.getUserByWallet(walletAddress);
      
      let status = 200;
      if (!user) {
        user = await storage.createUser(walletAddress);
        status = 201;
      }
      
      (req.session as any).userId = user.id;
      req.session.save((err) => {
        if (err) return res.status(500).json({ message: "Session error" });
        res.status(status).json(user);
      });
    } catch (e) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.get(api.auth.me.path, async (req, res) => {
    const userId = (req.session as any).userId;
    if (!userId) return res.status(401).json({ message: "Not logged in" });
    
    const user = await storage.getUser(userId);
    if (!user) return res.status(401).json({ message: "User not found" });
    
    res.json(user);
  });

  // Cases
  app.get(api.cases.list.path, async (req, res) => {
    const cases = await storage.getCases();
    res.json(cases);
  });

  app.get(api.cases.get.path, async (req, res) => {
    const id = parseInt(req.params.id);
    const caseData = await storage.getCase(id);
    if (!caseData) return res.status(404).json({ message: "Case not found" });
    res.json(caseData);
  });

  app.post(api.cases.open.path, async (req, res) => {
    const userId = (req.session as any).userId;
    if (!userId) return res.status(401).json({ message: "Not logged in" });

    const caseId = parseInt(req.params.id);
    const caseData = await storage.getCase(caseId);
    if (!caseData) return res.status(404).json({ message: "Case not found" });

    // Weighted random selection
    const totalWeight = caseData.drops.reduce((sum, drop) => sum + Number(drop.probability), 0);
    let random = Math.random() * totalWeight;
    
    let selectedDrop = caseData.drops[0];
    for (const drop of caseData.drops) {
      random -= Number(drop.probability);
      if (random <= 0) {
        selectedDrop = drop;
        break;
      }
    }

    await storage.addItemToUser(userId, selectedDrop.item.id);
    res.json({ item: selectedDrop.item });
  });

  // Daily Spin
  app.post(api.daily.spin.path, async (req, res) => {
    const userId = (req.session as any).userId;
    if (!userId) return res.status(401).json({ message: "Not logged in" });

    const user = await storage.getUser(userId);
    if (!user) return res.status(401).json({ message: "User not found" });

    // Check cooldown (24h)
    if (user.lastDailySpin) {
      const now = new Date();
      const diff = now.getTime() - new Date(user.lastDailySpin).getTime();
      const hours = diff / (1000 * 60 * 60);
      if (hours < 24) {
        return res.status(400).json({ 
          message: "Daily spin on cooldown", 
          cooldown: true 
        });
      }
    }

    // Logic for Daily Spin items
    // "0.1, 0.2, 0.3 TON" and "Snoop Dogg"
    const items = await storage.getItems();
    const ton01 = items.find(i => i.name === "0.1 TON");
    const ton02 = items.find(i => i.name === "0.2 TON");
    const ton03 = items.find(i => i.name === "0.3 TON");
    const snoop = items.find(i => i.name === "Snoop Dogg");
    const generic = items.filter(i => !["0.1 TON", "0.2 TON", "0.3 TON", "Snoop Dogg"].includes(i.name));

    // Simple probabilities for daily spin
    let selectedItem;
    const rand = Math.random();

    if (rand < 0.05 && snoop) { // 5% chance for Snoop
      selectedItem = snoop;
    } else if (rand < 0.2 && ton03) { // 15% chance for 0.3 TON
      selectedItem = ton03;
    } else if (rand < 0.4 && ton02) { // 20% chance for 0.2 TON
      selectedItem = ton02;
    } else if (rand < 0.7 && ton01) { // 30% chance for 0.1 TON
      selectedItem = ton01;
    } else {
      // 30% chance for random generic item
      selectedItem = generic[Math.floor(Math.random() * generic.length)];
    }

    if (!selectedItem) {
      selectedItem = generic[0]; // Fallback
    }

    await storage.addItemToUser(userId, selectedItem.id);
    await storage.updateUserLastDailySpin(userId);

    // If it's TON, update balance
    if (selectedItem.name.includes("TON")) {
      const amount = parseFloat(selectedItem.name.split(" ")[0]);
      const currentBalance = parseFloat(user.balance || "0");
      await storage.updateUserBalance(userId, (currentBalance + amount).toString());
    }

    res.json({ 
      item: selectedItem, 
      message: `You won ${selectedItem.name}!` 
    });
  });

  // User Items
  app.get(api.user.items.path, async (req, res) => {
    const userId = (req.session as any).userId;
    if (!userId) return res.status(401).json({ message: "Not logged in" });
    
    const items = await storage.getUserItems(userId);
    res.json(items);
  });

  // Seed data
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const cases = await storage.getCases();
  if (cases.length > 0) return;

  console.log("Seeding database...");

  // Create Items
  const snoop = await storage.createItem({
    name: "Snoop Dogg",
    type: "nft",
    value: "100",
    imageUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=snoop",
    isSnoopDogg: true
  });

  const ton01 = await storage.createItem({
    name: "0.1 TON",
    type: "token",
    value: "0.1",
    imageUrl: "https://cryptologos.cc/logos/toncoin-ton-logo.png",
  });

  const ton02 = await storage.createItem({
    name: "0.2 TON",
    type: "token",
    value: "0.2",
    imageUrl: "https://cryptologos.cc/logos/toncoin-ton-logo.png",
  });

  const ton03 = await storage.createItem({
    name: "0.3 TON",
    type: "token",
    value: "0.3",
    imageUrl: "https://cryptologos.cc/logos/toncoin-ton-logo.png",
  });

  const gift1 = await storage.createItem({
    name: "Telegram Premium Gift",
    type: "gift",
    value: "5",
    imageUrl: "/images/frog_case.png", // Using the user provided image
  });

  const gift2 = await storage.createItem({
    name: "Rare NFT",
    type: "nft",
    value: "50",
    imageUrl: "https://api.dicebear.com/7.x/shapes/svg?seed=rare",
  });

  // Create Cases
  const commonCase = await storage.createCase({
    name: "Common Case",
    price: "1",
    imageUrl: "/images/frog_case.png",
    description: "Start your journey here",
  });

  const rareCase = await storage.createCase({
    name: "Rare Case",
    price: "5",
    imageUrl: "https://api.dicebear.com/7.x/shapes/svg?seed=rarecase",
    description: "Better chances for NFTs",
  });

  // Drops
  await storage.addCaseDrop({ caseId: commonCase.id, itemId: gift1.id, probability: "0.8" });
  await storage.addCaseDrop({ caseId: commonCase.id, itemId: gift2.id, probability: "0.2" });

  await storage.addCaseDrop({ caseId: rareCase.id, itemId: gift1.id, probability: "0.3" });
  await storage.addCaseDrop({ caseId: rareCase.id, itemId: gift2.id, probability: "0.7" });

  console.log("Database seeded!");
}
